#include <ordo/core/store.h>

#include <stdexcept>

namespace ordo::core {

Store::Store(std::string name) : name_(std::move(name)) {}

Store::~Store() = default;

const std::string& Store::name() const {
    return name_;
}

StoreContext& Store::context() const {
    if (!context_) {
        throw std::logic_error("Store '" + name_ + "' is not registered with a kernel");
    }
    return *context_;
}

}  // namespace ordo::core
