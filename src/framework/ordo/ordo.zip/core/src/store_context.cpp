#include <ordo/core/store_context.h>

#include <ordo/core/app_kernel.h>

namespace ordo::core {

StoreContext::StoreContext(KernelKey, AppKernel& kernel, Dispatcher& dispatcher)
    : kernel_(&kernel), dispatcher_(&dispatcher) {}

std::shared_ptr<Store> StoreContext::store(std::string_view name) const {
    return kernel_->store(name);
}

}  // namespace ordo::core
