#pragma once

#include <memory>
#include <string_view>

#include <ordo/core/dispatcher.h>

namespace ordo::core {

class AppKernel;
class Store;

// Passkey minted only by AppKernel: methods taking a KernelKey are publicly
// visible but callable only from AppKernel code. Confines the friend surface
// to this empty token instead of opening a whole class to the kernel.
class KernelKey {
    friend class AppKernel;
    KernelKey() = default;

public:
    KernelKey(const KernelKey&) = delete;
    KernelKey& operator=(const KernelKey&) = delete;
};

// Narrow capability view handed to Stores at registration (least privilege):
// a Store may publish events and look up sibling stores -- nothing else.
// Owned by the kernel; lifetime == kernel lifetime, so a raw pointer to it
// held by a registered Store can never dangle.
class StoreContext {
public:
    // Constructible only by AppKernel (KernelKey passkey).
    StoreContext(KernelKey, AppKernel& kernel, Dispatcher& dispatcher);

    template <typename EventT>
    void send(const EventT& event) { dispatcher_->dispatch(event); }

    // Returns nullptr if no store is registered under that name.
    std::shared_ptr<Store> store(std::string_view name) const;

    // dynamic_pointer_cast convenience over store(); nullptr if absent, or if
    // the registered store is not actually a StoreT.
    template <typename StoreT>
    std::shared_ptr<StoreT> storeAs(std::string_view name) const {
        return std::dynamic_pointer_cast<StoreT>(store(name));
    }

private:
    AppKernel* kernel_;
    Dispatcher* dispatcher_;
};

}  // namespace ordo::core
