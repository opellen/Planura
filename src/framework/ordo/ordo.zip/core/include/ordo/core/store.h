#pragma once

#include <string>

#include <ordo/core/store_context.h>

namespace ordo::core {

class AppKernel;

// Base class for named domain data holders (the Proxy role). Concrete stores
// subclass this and are registered with an AppKernel under a unique name.
class Store {
public:
    explicit Store(std::string name);
    virtual ~Store();

    const std::string& name() const;

    // Called by AppKernel::registerStore() once this store is added to a
    // kernel; context() is already available when this runs.
    virtual void onRegister() {}

    // Called by AppKernel::removeStore() just before this store is dropped.
    virtual void onRemove() {}

    // Kernel-only (KernelKey passkey): wires/clears this store's context around
    // registration. Pass nullptr to clear.
    void setContext(KernelKey, StoreContext* context) noexcept { context_ = context; }

protected:
    // Available from just before onRegister() until just after onRemove().
    // Throws std::logic_error if the store is not currently registered.
    StoreContext& context() const;

    // Convenience for context().send(event).
    template <typename EventT>
    void send(const EventT& event) { context().send(event); }

private:
    std::string name_;
    StoreContext* context_ = nullptr;
};

}  // namespace ordo::core
