#pragma once

#include <algorithm>
#include <cstddef>
#include <functional>
#include <string_view>
#include <typeinfo>
#include <unordered_map>
#include <vector>

namespace ordo::core {

// Opaque per-subscription identifier, unique within one Dispatcher instance.
// Currently informational only -- bulk removal is by owner (see unsubscribe) --
// reserved for a future per-subscription unsubscribe.
using SubscriptionId = std::size_t;

// Trace record for one dispatch, delivered to the observer (if any) BEFORE
// the handlers run -- including dispatches with zero subscribers ("nobody
// listens" is exactly what a debugger wants to see).
struct DispatchRecord {
    std::size_t typeHash{};
    std::string_view eventName;    // empty when EventT has no eventName member
    std::size_t subscriberCount{};
};

// Typed-struct synchronous event bus. The struct type passed to subscribe<EventT>
// and dispatch<EventT> IS the event identity and payload spec -- there is no int
// enum and no void* payload anywhere in this public API.
class Dispatcher {
public:
    Dispatcher() = default;

    // owner is an opaque cookie (never dereferenced) used later for bulk removal
    // via unsubscribe(owner). Handlers for the same EventT fire in subscribe
    // order.
    //
    // Owner contract (policy-ordo-roles.md): pass the subscribing component's
    // OWN address, never another object's -- unsubscribe(owner) trusts the
    // cookie, so a foreign pointer silently detaches someone else's handlers.
    // The cookie is deliberately type-erased for now; a typed owner token is a
    // recorded deferred decision, revisited when the first subscriber outside
    // the sanctioned facades (Presenter, AppKernel's command registry) appears.
    template <typename EventT>
    SubscriptionId subscribe(const void* owner, std::function<void(const EventT&)> handler) {
        const SubscriptionId id = nextId_++;
        auto trampoline = [handler = std::move(handler)](const void* event) {
            handler(*static_cast<const EventT*>(event));
        };
        handlers_[typeid(EventT).hash_code()].push_back(Entry{owner, id, std::move(trampoline)});
        return id;
    }

    // Removes every subscription (any event type) registered with this owner.
    void unsubscribe(const void* owner);

    // Installs (or, with an empty function, clears) the single trace observer
    // slot. The intended client is the debug bridge.
    //
    // Contract (honor-system, same class as the same-type re-dispatch ban):
    // the observer must not subscribe, unsubscribe, or dispatch -- it is
    // trace-only and unguarded against reentrancy.
    void setObserver(std::function<void(const DispatchRecord&)> observer);

    // Synchronous 1:N broadcast to EventT subscribers, in subscribe order.
    //
    // Reentrancy contract -- implemented via a snapshot copy taken up front:
    //  - Handlers subscribed while this dispatch is running are appended to the
    //    LIVE per-event vector only, never to the snapshot below, so they cannot
    //    fire until a later dispatch.
    //  - Handlers unsubscribed while this dispatch is running are safe: each
    //    snapshotted trampoline is an independent std::function copy, so erasing
    //    the corresponding live entry (even the entry currently executing, e.g. a
    //    handler unsubscribing itself) never destroys a callable while it is
    //    still on the call stack.
    //  - Before invoking each snapshotted entry we re-check it is still present
    //    in the live vector by subscription id. This is what makes an
    //    unsubscribed handler stop firing for the rest of this dispatch, and it
    //    is id-based (not index-based) so that removing one entry does not
    //    silently skip a later, unrelated entry whose index shifted down.
    //
    // If an observer is set, it is invoked with a DispatchRecord BEFORE the
    // handler loop runs -- even when there are zero subscribers -- which is
    // why the "no subscribers" early return happens AFTER observing rather
    // than at the top of the function.
    template <typename EventT>
    void dispatch(const EventT& event) {
        const std::size_t hash = typeid(EventT).hash_code();
        auto it = handlers_.find(hash);

        if (observer_) {
            DispatchRecord record;
            record.typeHash = hash;
            record.subscriberCount = (it != handlers_.end()) ? it->second.size() : 0;
            if constexpr (requires { EventT::eventName; }) {
                record.eventName = EventT::eventName;
            }
            observer_(record);
        }

        if (it == handlers_.end()) {
            return;
        }
        const std::vector<Entry> snapshot = it->second;

        for (const Entry& entry : snapshot) {
            const std::vector<Entry>& live = handlers_[hash];
            const bool stillSubscribed =
                std::any_of(live.begin(), live.end(), [&entry](const Entry& e) { return e.id == entry.id; });
            if (stillSubscribed) {
                entry.trampoline(&event);
            }
        }
    }

private:
    struct Entry {
        const void* owner;
        SubscriptionId id;
        std::function<void(const void*)> trampoline;
    };

    std::unordered_map<std::size_t, std::vector<Entry>> handlers_;
    SubscriptionId nextId_ = 1;
    std::function<void(const DispatchRecord&)> observer_;
};

}  // namespace ordo::core
