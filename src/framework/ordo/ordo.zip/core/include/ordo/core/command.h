#pragma once

namespace ordo::core {

class AppKernel;

// Non-template base so all commands, regardless of the event type they handle,
// share one pointer type (e.g. inside AppKernel's per-event factories).
//
// The undo() hook is deliberately absent until mvp.M9 -- do not add it yet.
class ICommand {
public:
    virtual ~ICommand() = default;
};

// A transaction object created fresh per dispatched EventT (see
// AppKernel::registerCommand). Subclasses implement execute() to read the event
// payload and act on the kernel's stores/dispatcher.
template <typename EventT>
class Command : public ICommand {
public:
    virtual void execute(AppKernel& kernel, const EventT& event) = 0;
};

}  // namespace ordo::core
