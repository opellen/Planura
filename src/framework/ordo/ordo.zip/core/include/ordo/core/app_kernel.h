#pragma once

#include <cstddef>
#include <memory>
#include <string>
#include <string_view>
#include <type_traits>
#include <typeinfo>
#include <unordered_map>

#include <ordo/core/command.h>
#include <ordo/core/dispatcher.h>
#include <ordo/core/store.h>
#include <ordo/core/store_context.h>

namespace ordo::core {

// Facade over one Dispatcher plus named Stores and per-event Command factories.
// Instantiable, never a singleton: two AppKernel instances are fully isolated
// "cores" -- a store or command registered on one is invisible to the other.
class AppKernel {
public:
    AppKernel();

    Dispatcher& dispatcher();

    // Registers (or replaces, by name) a store: gives it this kernel's
    // StoreContext and calls store->onRegister(). If a store is already
    // registered under this name, that old store gets onRemove() and loses
    // its context first.
    void registerStore(std::shared_ptr<Store> store);

    // Returns nullptr if no store is registered under that name.
    std::shared_ptr<Store> store(std::string_view name);

    // dynamic_pointer_cast convenience over store(); nullptr if absent, or if the
    // registered store is not actually a StoreT.
    template <typename StoreT>
    std::shared_ptr<StoreT> storeAs(std::string_view name) {
        return std::dynamic_pointer_cast<StoreT>(store(name));
    }

    // Calls onRemove() on the store and drops it. Returns false (no-op) if no
    // store is registered under that name.
    bool removeStore(std::string_view name);

    // Subscribes a factory for EventT on this kernel's dispatcher: each dispatch
    // of EventT constructs a fresh CommandT via std::make_unique and calls
    // execute(*this, event) once.
    //
    // Calling this again for an EventT that already has a registered command
    // REPLACES the old factory -- the previous subscription is unsubscribed
    // first, so only the newest CommandT executes on subsequent dispatches.
    template <typename EventT, typename CommandT>
    void registerCommand() {
        static_assert(std::is_base_of<Command<EventT>, CommandT>::value,
                      "CommandT must derive from Command<EventT>");
        removeCommand<EventT>();
        AppKernel* kernel = this;
        dispatcher_.subscribe<EventT>(commandOwner<EventT>(), [kernel](const EventT& event) {
            auto command = std::make_unique<CommandT>();
            command->execute(*kernel, event);
        });
    }

    // Unsubscribes the command factory (if any) registered for EventT. Other
    // event types' command factories on this kernel are unaffected.
    template <typename EventT>
    void removeCommand() {
        dispatcher_.unsubscribe(commandOwner<EventT>());
    }

    // Convenience for dispatcher().dispatch(e).
    template <typename EventT>
    void send(const EventT& event) {
        dispatcher_.dispatch(event);
    }

private:
    // A stable-address token, one per (this kernel instance, EventT), used as the
    // Dispatcher owner cookie for that event's command factory subscription.
    //
    // A plain `this` cannot be reused as the owner for every EventT: Dispatcher
    // ::unsubscribe(owner) removes ALL subscriptions of that owner, but
    // removeCommand<EventT>() must only tear down the one factory for EventT and
    // leave this kernel's other registered commands running. unordered_map
    // element addresses are stable across insertion of unrelated keys (only
    // erasing a key invalidates its address), so this pointer stays valid for the
    // kernel's lifetime once the slot exists.
    template <typename EventT>
    const void* commandOwner() {
        return &commandOwnerTokens_[typeid(EventT).hash_code()];
    }

    Dispatcher dispatcher_;
    StoreContext storeContext_;  // constructed after dispatcher_ -- member order matters
    std::unordered_map<std::string, std::shared_ptr<Store>> stores_;
    std::unordered_map<std::size_t, int> commandOwnerTokens_;
};

}  // namespace ordo::core
